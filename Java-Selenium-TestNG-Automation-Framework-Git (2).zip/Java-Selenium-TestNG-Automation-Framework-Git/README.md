# GitHub-Test-Framework
This is an example of test automation framework usind Selenium WebDriver and TestNG. Takes data for the test 
from excel file and saves test result from each step and certain data. Name, password, browser and using assertion or verifying are taken from the config.properties file.
